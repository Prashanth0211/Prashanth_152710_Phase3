package com.cg.paymentjpa.dto;

import com.cg.paymentjpa.bean.Customer;

import junit.framework.TestCase;

public class CustomerTest extends TestCase {

	Customer cust = new Customer();

	public void testGetWallet() {

	}

	public void testGetCustomerName() {
		cust.setName("Prashanth");
		assertEquals("Prashanth", cust.getName());
	}

	public void testGetPhoneNumber() {
		cust.setPhNumber("7660824282");
		assertEquals("7660824282", cust.getPhNumber());

	}

	public void testGetGender() {
		cust.setGender("male");
		assertEquals("male", cust.getGender());
	}

	public void testGetAge() {
		cust.setAge(22);
		assertEquals(22, cust.getAge());

	}

	public void testGetUser_ID() {
		cust.setUserId("Prashanth11");
		assertEquals("Prashanth11", cust.getUserId());
	}

	public void testGetPassword() {
		cust.getWallet().setPassword("Prashanth@11");
		assertEquals("Prashanth@11", cust.getWallet().getPassword());

	}

}
